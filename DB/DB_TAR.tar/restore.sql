--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE proje;
--
-- Name: proje; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE proje WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE proje OWNER TO postgres;

\connect proje

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: kullanici; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kullanici (
    kullanici_id integer NOT NULL,
    isim character varying NOT NULL,
    email character varying NOT NULL,
    parola character varying NOT NULL
);


ALTER TABLE public.kullanici OWNER TO postgres;

--
-- Name: kullanici_kullanici_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kullanici_kullanici_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kullanici_kullanici_id_seq OWNER TO postgres;

--
-- Name: kullanici_kullanici_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kullanici_kullanici_id_seq OWNED BY public.kullanici.kullanici_id;


--
-- Name: note; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.note (
    note_id integer NOT NULL,
    note character varying NOT NULL
);


ALTER TABLE public.note OWNER TO postgres;

--
-- Name: note_note_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.note_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.note_note_id_seq OWNER TO postgres;

--
-- Name: note_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.note_note_id_seq OWNED BY public.note.note_id;


--
-- Name: soru; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.soru (
    soru_id integer NOT NULL,
    soru character varying NOT NULL,
    cevap_bir character varying NOT NULL,
    cevap_iki character varying NOT NULL,
    cevap_uc character varying NOT NULL,
    cevap_dort character varying NOT NULL,
    cevap_dogru character varying NOT NULL
);


ALTER TABLE public.soru OWNER TO postgres;

--
-- Name: soru_soru_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.soru_soru_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.soru_soru_id_seq OWNER TO postgres;

--
-- Name: soru_soru_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.soru_soru_id_seq OWNED BY public.soru.soru_id;


--
-- Name: kullanici kullanici_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kullanici ALTER COLUMN kullanici_id SET DEFAULT nextval('public.kullanici_kullanici_id_seq'::regclass);


--
-- Name: note note_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note ALTER COLUMN note_id SET DEFAULT nextval('public.note_note_id_seq'::regclass);


--
-- Name: soru soru_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soru ALTER COLUMN soru_id SET DEFAULT nextval('public.soru_soru_id_seq'::regclass);


--
-- Data for Name: kullanici; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kullanici (kullanici_id, isim, email, parola) FROM stdin;
\.
COPY public.kullanici (kullanici_id, isim, email, parola) FROM '$$PATH$$/3270.dat';

--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.note (note_id, note) FROM stdin;
\.
COPY public.note (note_id, note) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: soru; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.soru (soru_id, soru, cevap_bir, cevap_iki, cevap_uc, cevap_dort, cevap_dogru) FROM stdin;
\.
COPY public.soru (soru_id, soru, cevap_bir, cevap_iki, cevap_uc, cevap_dort, cevap_dogru) FROM '$$PATH$$/3272.dat';

--
-- Name: kullanici_kullanici_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kullanici_kullanici_id_seq', 16, true);


--
-- Name: note_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.note_note_id_seq', 5, true);


--
-- Name: soru_soru_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.soru_soru_id_seq', 5, true);


--
-- Name: kullanici kullanici_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kullanici
    ADD CONSTRAINT kullanici_pkey PRIMARY KEY (kullanici_id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (note_id);


--
-- Name: soru soru_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soru
    ADD CONSTRAINT soru_pkey PRIMARY KEY (soru_id);


--
-- PostgreSQL database dump complete
--

